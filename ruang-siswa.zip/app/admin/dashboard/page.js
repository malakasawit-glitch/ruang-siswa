'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { ShieldCheck, Inbox, Clock4, Loader2, CheckCircle2, AlertTriangle, Trash2, LogOut, Home, MessageSquare } from 'lucide-react';

const CAT_COLORS = {
  Akademik: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  Fasilitas: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
  Kebersihan: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  Kantin: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  Ekstrakurikuler: 'bg-pink-500/15 text-pink-400 border-pink-500/30',
  Lainnya: 'bg-slate-500/15 text-slate-400 border-slate-500/30',
};
const STATUS_COLORS = {
  'Menunggu Review': 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  'Diproses': 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  'Selesai': 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
};

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <Card className="bg-card/60 backdrop-blur border-border/60">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
          </div>
          <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${color}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState(null);
  const [posts, setPosts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  const authHeaders = () => ({ Authorization: `Bearer ${localStorage.getItem('rs_admin_token')}` });

  const load = useCallback(async () => {
    setLoading(true);
    const [s, p] = await Promise.all([
      fetch('/api/admin/stats', { headers: authHeaders() }).then(r=>r.json()),
      fetch(`/api/admin/posts?filter=${filter}`, { headers: authHeaders() }).then(r=>r.json()),
    ]);
    if (s.error) { toast.error('Sesi habis, login ulang'); router.push('/admin/login'); return; }
    setStats(s);
    setPosts(p.posts || []);
    setLoading(false);
  }, [filter, router]);

  useEffect(() => {
    if (!localStorage.getItem('rs_admin_token')) { router.push('/admin/login'); return; }
    load();
  }, [load, router]);

  const updatePost = async (id, body) => {
    const res = await fetch(`/api/admin/posts/${id}`, { method:'PATCH', headers:{ 'Content-Type':'application/json', ...authHeaders() }, body: JSON.stringify(body) });
    const d = await res.json();
    if (d.error) return toast.error(d.error);
    toast.success('Berhasil diperbarui');
    load();
  };

  const deletePost = async (id) => {
    if (!confirm('Hapus aspirasi ini?')) return;
    const res = await fetch(`/api/admin/posts/${id}`, { method:'DELETE', headers: authHeaders() });
    const d = await res.json();
    if (d.error) return toast.error(d.error);
    toast.success('Aspirasi dihapus');
    load();
  };

  const logout = () => { localStorage.removeItem('rs_admin_token'); router.push('/admin/login'); };

  return (
    <div className="min-h-screen gradient-bg">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <ShieldCheck className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link href="/"><Home className="h-4 w-4" /></Link></Button>
            <Button variant="ghost" size="sm" onClick={logout}><LogOut className="h-4 w-4" /></Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-5xl">
        <h1 className="text-2xl font-bold mb-1">Ringkasan</h1>
        <p className="text-sm text-muted-foreground mb-5">Pantau & kelola aspirasi siswa.</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard icon={Inbox} label="Total Aspirasi" value={stats?.total ?? '–'} color="bg-primary/15 text-primary" />
          <StatCard icon={Clock4} label="Menunggu Review" value={stats?.menunggu ?? '–'} color="bg-yellow-500/15 text-yellow-400" />
          <StatCard icon={Loader2} label="Diproses" value={stats?.diproses ?? '–'} color="bg-blue-500/15 text-blue-400" />
          <StatCard icon={CheckCircle2} label="Selesai" value={stats?.selesai ?? '–'} color="bg-emerald-500/15 text-emerald-400" />
        </div>

        {stats?.flagged > 0 && (
          <div className="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 text-red-300 p-3 flex items-center gap-2 text-sm">
            <AlertTriangle className="h-4 w-4" />
            <span>{stats.flagged} aspirasi menunggu moderasi (terdeteksi pelanggaran).</span>
            <Button size="sm" variant="outline" className="ml-auto" onClick={() => setFilter('pending_review')}>Tinjau</Button>
          </div>
        )}

        <Tabs value={filter} onValueChange={setFilter} className="mb-4">
          <TabsList className="flex flex-wrap h-auto">
            <TabsTrigger value="all">Semua</TabsTrigger>
            <TabsTrigger value="pending_review">Perlu Moderasi</TabsTrigger>
            <TabsTrigger value="menunggu">Menunggu</TabsTrigger>
            <TabsTrigger value="diproses">Diproses</TabsTrigger>
            <TabsTrigger value="selesai">Selesai</TabsTrigger>
          </TabsList>
        </Tabs>

        {loading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-28 rounded-xl bg-card/40 animate-pulse" />)}</div>
        ) : posts.length === 0 ? (
          <Card className="p-10 text-center bg-card/60"><MessageSquare className="h-10 w-10 mx-auto text-muted-foreground mb-2" /><p className="text-muted-foreground">Tidak ada aspirasi.</p></Card>
        ) : (
          <div className="space-y-3">
            {posts.map(p => (
              <Card key={p.id} className={`bg-card/60 backdrop-blur border-border/60 ${p.flagged && !p.approved ? 'border-red-500/40' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-2 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <Badge variant="outline" className={CAT_COLORS[p.category]}>{p.category}</Badge>
                      <Badge variant="outline" className={STATUS_COLORS[p.status]}>{p.status}</Badge>
                      {p.flagged && !p.approved && (
                        <Badge variant="outline" className="bg-red-500/15 text-red-400 border-red-500/30 gap-1">
                          <AlertTriangle className="h-3 w-3" /> Perlu Review
                        </Badge>
                      )}
                      <span className="text-muted-foreground">{new Date(p.createdAt).toLocaleString('id-ID')}</span>
                      <span className="text-muted-foreground">· {p.supportCount || 0} dukungan</span>
                    </div>
                  </div>
                  <h3 className="font-semibold">{p.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">{p.content}</p>
                  {p.moderationFlags?.length > 0 && (
                    <div className="mt-2 text-xs text-red-400">Pelanggaran terdeteksi: {p.moderationFlags.join(', ')}</div>
                  )}
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {p.flagged && !p.approved && (
                      <>
                        <Button size="sm" onClick={() => updatePost(p.id, { action: 'approve' })}>Setujui</Button>
                        <Button size="sm" variant="outline" onClick={() => updatePost(p.id, { action: 'reject' })}>Tolak</Button>
                      </>
                    )}
                    <Select value={p.status} onValueChange={v => updatePost(p.id, { status: v })}>
                      <SelectTrigger className="h-8 w-auto min-w-[160px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Menunggu Review">Menunggu Review</SelectItem>
                        <SelectItem value="Diproses">Diproses</SelectItem>
                        <SelectItem value="Selesai">Selesai</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="sm" variant="destructive" onClick={() => deletePost(p.id)} className="ml-auto gap-1">
                      <Trash2 className="h-3.5 w-3.5" /> Hapus
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
