'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { KeyRound } from 'lucide-react';

export default function ChangePassword() {
  const router = useRouter();
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (pw.length < 6) return toast.error('Password minimal 6 karakter');
    if (pw !== pw2) return toast.error('Password tidak sama');
    setLoading(true);
    const token = localStorage.getItem('rs_admin_token');
    const res = await fetch('/api/auth/admin-change-password', { method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` }, body: JSON.stringify({ newPassword: pw }) });
    const d = await res.json();
    setLoading(false);
    if (d.error) return toast.error(d.error);
    toast.success('Password berhasil diubah');
    router.push('/admin/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 gradient-bg">
      <Card className="w-full max-w-md bg-card/60 backdrop-blur border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" /> Ganti Password</CardTitle>
          <CardDescription>Demi keamanan, ganti password default sebelum melanjutkan.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label>Password Baru</Label>
              <Input type="password" required minLength={6} value={pw} onChange={e=>setPw(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Konfirmasi Password</Label>
              <Input type="password" required value={pw2} onChange={e=>setPw2(e.target.value)} />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>{loading?'Menyimpan...':'Ganti Password'}</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
