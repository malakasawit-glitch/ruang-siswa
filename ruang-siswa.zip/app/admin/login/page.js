'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ShieldCheck, ArrowLeft } from 'lucide-react';

export default function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@ruangsiswa.id');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/auth/admin-login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) });
    const d = await res.json();
    setLoading(false);
    if (d.error) { toast.error(d.error); return; }
    localStorage.setItem('rs_admin_token', d.token);
    toast.success('Login admin berhasil');
    if (d.user?.mustChangePassword) router.push('/admin/change-password');
    else router.push('/admin/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 gradient-bg">
      <div className="w-full max-w-md">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" /> Kembali
        </Link>
        <Card className="bg-card/60 backdrop-blur border-border/60">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                <ShieldCheck className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-lg">Admin Ruang Siswa</span>
            </div>
            <CardTitle>Login Admin</CardTitle>
            <CardDescription>Akses dashboard moderasi & statistik.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-2">
                <Label>Email Admin</Label>
                <Input type="email" required value={email} onChange={e=>setEmail(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input type="password" required value={password} onChange={e=>setPassword(e.target.value)} />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>{loading?'Memproses...':'Masuk'}</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
