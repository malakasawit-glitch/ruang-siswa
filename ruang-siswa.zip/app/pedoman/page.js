import Link from 'next/link';
import { ArrowLeft, Shield, Lock, MessageCircle, AlertTriangle, ThumbsUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function PedomanPage() {
  const items = [
    { icon: Shield, title: 'Identitas Anonim', desc: 'Postinganmu tidak menampilkan nama, email, atau identitas pribadi apa pun.' },
    { icon: Lock, title: 'Data Aman', desc: 'Akun digunakan hanya untuk verifikasi dukungan. Tidak ada yang bisa melihat siapa yang memposting.' },
    { icon: MessageCircle, title: 'Bahasa yang Baik', desc: 'Gunakan bahasa sopan. Hindari kata kasar, SARA, dan ujaran kebencian.' },
    { icon: AlertTriangle, title: 'Jangan Sebut Identitas', desc: 'Dilarang menyebut nama orang, nomor HP, NIK, atau alamat. Pelanggaran otomatis di-review admin.' },
    { icon: ThumbsUp, title: 'Dukung Aspirasi', desc: 'Berikan dukungan ke aspirasi yang menurutmu penting. Satu akun = satu dukungan per aspirasi.' },
  ];
  return (
    <div className="min-h-screen px-4 py-6 gradient-bg">
      <div className="max-w-2xl mx-auto">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" /> Kembali
        </Link>
        <h1 className="text-3xl font-bold mb-2 gradient-text">Pedoman Komunitas</h1>
        <p className="text-muted-foreground mb-6">Aturan singkat agar Ruang Siswa tetap aman dan bermanfaat.</p>
        <div className="space-y-3">
          {items.map((it, i) => (
            <Card key={i} className="bg-card/60 backdrop-blur border-border/60">
              <CardContent className="p-4 flex gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/15 text-primary flex items-center justify-center shrink-0">
                  <it.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold">{it.title}</h3>
                  <p className="text-sm text-muted-foreground mt-0.5">{it.desc}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
