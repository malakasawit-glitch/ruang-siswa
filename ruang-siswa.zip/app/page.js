'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { Search, Sparkles, TrendingUp, Clock, Heart, Shield, ArrowUp, Home, Flame, Grid3x3, BookOpen, Plus, LogOut, UserCircle2, MessageSquare, ShieldCheck } from 'lucide-react';

const CATEGORIES = ['Semua','Akademik','Fasilitas','Kebersihan','Kantin','Ekstrakurikuler','Lainnya'];

const CAT_COLORS = {
  Akademik: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  Fasilitas: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
  Kebersihan: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  Kantin: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  Ekstrakurikuler: 'bg-pink-500/15 text-pink-400 border-pink-500/30',
  Lainnya: 'bg-slate-500/15 text-slate-400 border-slate-500/30',
};

const STATUS_COLORS = {
  'Menunggu Review': 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  'Diproses': 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  'Selesai': 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
};

function timeAgo(d) {
  const diff = (Date.now() - new Date(d).getTime()) / 1000;
  if (diff < 60) return 'baru saja';
  if (diff < 3600) return `${Math.floor(diff/60)} menit lalu`;
  if (diff < 86400) return `${Math.floor(diff/3600)} jam lalu`;
  if (diff < 604800) return `${Math.floor(diff/86400)} hari lalu`;
  return new Date(d).toLocaleDateString('id-ID');
}

function PostCard({ post, onSupport, user }) {
  const handleSupport = async () => {
    if (!user) { toast.error('Silakan login untuk mendukung aspirasi'); return; }
    onSupport(post.id);
  };
  return (
    <Card className="overflow-hidden border-border/60 bg-card/60 backdrop-blur hover:border-primary/40 transition-all">
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10 border border-border">
            <AvatarFallback className="bg-gradient-to-br from-primary to-blue-500 text-primary-foreground text-xs font-bold">AN</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">Anonim</span>
              <span>·</span>
              <span>{timeAgo(post.createdAt)}</span>
              <Badge variant="outline" className={`text-[10px] py-0 px-1.5 ${CAT_COLORS[post.category] || ''}`}>{post.category}</Badge>
              <Badge variant="outline" className={`text-[10px] py-0 px-1.5 ${STATUS_COLORS[post.status] || ''}`}>{post.status}</Badge>
            </div>
            <h3 className="mt-1.5 font-semibold text-base sm:text-lg leading-snug">{post.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground whitespace-pre-wrap line-clamp-5">{post.content}</p>
            <div className="mt-3 flex items-center gap-2">
              <Button
                size="sm"
                variant={post.hasSupported ? 'default' : 'outline'}
                onClick={handleSupport}
                className="gap-1.5 h-8"
              >
                <ArrowUp className={`h-4 w-4 ${post.hasSupported ? 'fill-current' : ''}`} />
                <span className="font-semibold">{post.supportCount || 0}</span>
                <span className="hidden sm:inline">Dukung</span>
              </Button>
              <Button size="sm" variant="ghost" className="gap-1.5 h-8 text-muted-foreground" disabled>
                <MessageSquare className="h-4 w-4" />
                <span className="text-xs">Aspirasi</span>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function App() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('terbaru');
  const [category, setCategory] = useState('Semua');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');

  useEffect(() => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('rs_token') : null;
    if (token) {
      fetch('/api/me', { headers: { Authorization: `Bearer ${token}` } })
        .then(r => r.json())
        .then(d => { if (d.user) setUser(d.user); else localStorage.removeItem('rs_token'); })
        .catch(() => {});
    }
  }, []);

  const loadPosts = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({ tab, category, search });
    const token = localStorage.getItem('rs_token');
    const res = await fetch(`/api/posts?${params}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    const d = await res.json();
    setPosts(d.posts || []);
    setLoading(false);
  }, [tab, category, search]);

  useEffect(() => { loadPosts(); }, [loadPosts]);

  const handleSupport = async (id) => {
    const token = localStorage.getItem('rs_token');
    const res = await fetch(`/api/posts/${id}/support`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } });
    const d = await res.json();
    if (d.error) { toast.error(d.error); return; }
    setPosts(prev => prev.map(p => p.id === id ? { ...p, hasSupported: d.hasSupported, supportCount: d.supportCount } : p));
    toast.success(d.hasSupported ? 'Aspirasi didukung!' : 'Dukungan dibatalkan');
  };

  const handleLogout = () => {
    localStorage.removeItem('rs_token');
    setUser(null);
    toast.success('Berhasil keluar');
  };

  const onSearchSubmit = (e) => {
    e.preventDefault();
    setSearch(searchInput);
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0 gradient-bg">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <Link href="/" className="flex items-center gap-2 font-bold">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-blue-500 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="text-lg gradient-text">Ruang Siswa</span>
          </Link>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <Button asChild size="sm" className="gap-1.5">
                  <Link href="/post"><Plus className="h-4 w-4" /><span className="hidden sm:inline">Aspirasi</span></Link>
                </Button>
                <Button size="sm" variant="ghost" onClick={handleLogout} className="gap-1.5"><LogOut className="h-4 w-4" /><span className="hidden sm:inline">Keluar</span></Button>
              </>
            ) : (
              <>
                <Button asChild size="sm" variant="ghost"><Link href="/login">Masuk</Link></Button>
                <Button asChild size="sm"><Link href="/register">Daftar</Link></Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-4 pt-8 pb-6 sm:pt-12 sm:pb-10 text-center">
        <Badge variant="outline" className="mb-4 gap-1.5 border-emerald-500/40 bg-emerald-500/10 text-emerald-400">
          <Shield className="h-3 w-3" />
          100% Anonim
        </Badge>
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
          <span className="gradient-text">Aspirasi Siswa</span>
        </h1>
        <p className="mt-3 max-w-2xl mx-auto text-sm sm:text-base text-muted-foreground px-2">
          Ekspresikan ide, keluhan, atau saran untuk sekolahmu. Aman, terlindungi, dan transparan.
        </p>
        <form onSubmit={onSearchSubmit} className="mt-6 max-w-xl mx-auto relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            placeholder="Cari aspirasi..."
            className="pl-10 h-12 bg-card/60 backdrop-blur border-border/60"
          />
        </form>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
          {CATEGORIES.map(c => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`shrink-0 px-4 h-9 rounded-full border text-sm font-medium transition ${
                category === c ? 'bg-primary text-primary-foreground border-primary' : 'bg-card/60 text-muted-foreground border-border hover:text-foreground'
              }`}
            >{c}</button>
          ))}
        </div>
      </section>

      {/* Tabs + Feed */}
      <section className="container mx-auto px-4 max-w-2xl">
        <Tabs value={tab} onValueChange={setTab} className="mb-4">
          <TabsList className="grid grid-cols-3 w-full bg-card/60 backdrop-blur">
            <TabsTrigger value="terbaru" className="gap-1.5"><Clock className="h-3.5 w-3.5" />Terbaru</TabsTrigger>
            <TabsTrigger value="trending" className="gap-1.5"><TrendingUp className="h-3.5 w-3.5" />Trending</TabsTrigger>
            <TabsTrigger value="terbanyak" className="gap-1.5"><Heart className="h-3.5 w-3.5" /><span className="hidden sm:inline">Terbanyak</span><span className="sm:hidden">Top</span></TabsTrigger>
          </TabsList>
        </Tabs>

        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <div key={i} className="h-32 rounded-xl bg-card/40 animate-pulse" />)}
          </div>
        ) : posts.length === 0 ? (
          <Card className="p-10 text-center bg-card/60">
            <MessageSquare className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">Belum ada aspirasi. Jadilah yang pertama!</p>
            {user && (
              <Button asChild className="mt-4"><Link href="/post">Buat Aspirasi</Link></Button>
            )}
          </Card>
        ) : (
          <div className="space-y-3">
            {posts.map(p => <PostCard key={p.id} post={p} onSupport={handleSupport} user={user} />)}
          </div>
        )}

        <div className="mt-12 text-center text-xs text-muted-foreground">
          <Link href="/admin/login" className="inline-flex items-center gap-1 hover:text-foreground">
            <ShieldCheck className="h-3 w-3" /> Login Admin
          </Link>
        </div>
      </section>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-background/95 backdrop-blur-xl">
        <div className="grid grid-cols-4 h-16">
          <button onClick={() => { setTab('terbaru'); setCategory('Semua'); window.scrollTo({top:0,behavior:'smooth'}); }} className="flex flex-col items-center justify-center gap-0.5 text-[11px] text-foreground">
            <Home className="h-5 w-5" />Beranda
          </button>
          <button onClick={() => { setTab('trending'); window.scrollTo({top:0,behavior:'smooth'}); }} className={`flex flex-col items-center justify-center gap-0.5 text-[11px] ${tab==='trending'?'text-primary':'text-muted-foreground'}`}>
            <Flame className="h-5 w-5" />Trending
          </button>
          <button onClick={() => document.getElementById('cat-anchor')?.scrollIntoView()} className="flex flex-col items-center justify-center gap-0.5 text-[11px] text-muted-foreground">
            <Grid3x3 className="h-5 w-5" />Kategori
          </button>
          <Link href="/pedoman" className="flex flex-col items-center justify-center gap-0.5 text-[11px] text-muted-foreground">
            <BookOpen className="h-5 w-5" />Pedoman
          </Link>
        </div>
      </nav>
      <div id="cat-anchor" />
    </div>
  );
}

export default App;
