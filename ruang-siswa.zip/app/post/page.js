'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ArrowLeft, Shield, Sparkles } from 'lucide-react';

const CATEGORIES = ['Akademik','Fasilitas','Kebersihan','Kantin','Ekstrakurikuler','Lainnya'];

export default function PostPage() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('rs_token');
    if (!token) { router.push('/login'); return; }
    fetch('/api/me', { headers: { Authorization: `Bearer ${token}` } }).then(r=>r.json()).then(d=>{
      if (!d.user) { localStorage.removeItem('rs_token'); router.push('/login'); }
      else setChecked(true);
    });
  }, [router]);

  const submit = async (e) => {
    e.preventDefault();
    if (!category) { toast.error('Pilih kategori dulu'); return; }
    setLoading(true);
    const token = localStorage.getItem('rs_token');
    const res = await fetch('/api/posts', { method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` }, body: JSON.stringify({ title, content, category }) });
    const d = await res.json();
    setLoading(false);
    if (d.error) { toast.error(d.error); return; }
    if (d.post?.flagged) {
      toast.warning('Aspirasi diterima namun perlu review admin sebelum tampil.');
    } else {
      toast.success('Aspirasi berhasil dipublikasikan!');
    }
    router.push('/');
  };

  if (!checked) return null;

  return (
    <div className="min-h-screen px-4 py-6 gradient-bg">
      <div className="max-w-2xl mx-auto">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="h-4 w-4" /> Kembali ke Beranda
        </Link>
        <Card className="bg-card/60 backdrop-blur border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" /> Buat Aspirasi</CardTitle>
            <CardDescription>
              <Badge variant="outline" className="gap-1 border-emerald-500/40 bg-emerald-500/10 text-emerald-400 mt-1">
                <Shield className="h-3 w-3" /> Diposting Anonim
              </Badge>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-2">
                <Label>Judul</Label>
                <Input required maxLength={200} value={title} onChange={e=>setTitle(e.target.value)} placeholder="Contoh: Perbaikan AC di kelas 12 IPA" />
              </div>
              <div className="space-y-2">
                <Label>Kategori</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Isi Aspirasi</Label>
                <Textarea required maxLength={4000} rows={8} value={content} onChange={e=>setContent(e.target.value)} placeholder="Ceritakan ide, keluhan, atau saranmu..." />
                <p className="text-xs text-muted-foreground">Hindari menyebut nama orang, nomor telepon, atau alamat. {content.length}/4000</p>
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={loading} className="flex-1">{loading ? 'Mengirim...' : 'Posting Aspirasi'}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
