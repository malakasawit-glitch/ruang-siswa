import { NextResponse } from 'next/server';
import { MongoClient } from 'mongodb';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';

const MONGO_URL = process.env.MONGO_URL;
const DB_NAME = process.env.DB_NAME || 'ruang_siswa';
const JWT_SECRET = process.env.JWT_SECRET || 'ruang-siswa-secret';

let client;
let db;

async function getDb() {
  if (!client) {
    client = new MongoClient(MONGO_URL);
    await client.connect();
    db = client.db(DB_NAME);
    await ensureSeed();
  }
  return db;
}

async function ensureSeed() {
  const admins = db.collection('admins');
  const existing = await admins.findOne({ email: 'admin@ruangsiswa.id' });
  if (!existing) {
    const hash = await bcrypt.hash('admin123', 10);
    await admins.insertOne({
      id: uuidv4(),
      email: 'admin@ruangsiswa.id',
      password: hash,
      role: 'admin',
      mustChangePassword: true,
      createdAt: new Date()
    });
    console.log('[seed] Default admin created');
  }
  await db.collection('posts').createIndex({ createdAt: -1 });
  await db.collection('posts').createIndex({ supportCount: -1 });
}

function json(data, status = 200) {
  return NextResponse.json(data, { status });
}

function getToken(req) {
  const h = req.headers.get('authorization') || '';
  if (h.startsWith('Bearer ')) return h.slice(7);
  return null;
}

function verifyToken(req) {
  try {
    const t = getToken(req);
    if (!t) return null;
    return jwt.verify(t, JWT_SECRET);
  } catch {
    return null;
  }
}

const BAD_WORDS = ['anjing','bangsat','kontol','memek','tolol','goblok','bajingan','brengsek','tai','asu','jancok','ngentot','idiot','bodoh sekali','fuck','shit','bitch','asshole'];
const PHONE_RE = /(\+?62|0)8[1-9][0-9]{6,11}/g;
const NIK_RE = /\b\d{16}\b/g;
const ADDRESS_RE = /(jl\.|jalan|gg\.|gang)\s+[a-z0-9\s.,]{5,}/gi;

function autoModerate(title, content) {
  const text = `${title} ${content}`.toLowerCase();
  const flags = [];
  for (const w of BAD_WORDS) {
    if (text.includes(w)) { flags.push(`Kata kasar: ${w}`); break; }
  }
  if (PHONE_RE.test(text)) flags.push('Mengandung nomor telepon');
  if (NIK_RE.test(text)) flags.push('Mengandung NIK/identitas');
  if (ADDRESS_RE.test(text)) flags.push('Mengandung alamat spesifik');
  return flags;
}

function cleanPost(p) {
  if (!p) return p;
  const { _id, ...rest } = p;
  return rest;
}

// ============ ROUTER ============
async function handle(req, { params }) {
  const database = await getDb();
  const path = (params?.path || []).join('/');
  const method = req.method;
  const url = new URL(req.url);

  try {
    // -------- AUTH --------
    if (path === 'auth/register' && method === 'POST') {
      const { email, password } = await req.json();
      if (!email || !password || password.length < 6) return json({ error: 'Email dan password (min 6 karakter) wajib diisi' }, 400);
      const users = database.collection('users');
      const exists = await users.findOne({ email: email.toLowerCase() });
      if (exists) return json({ error: 'Email sudah terdaftar' }, 400);
      const hash = await bcrypt.hash(password, 10);
      const user = { id: uuidv4(), email: email.toLowerCase(), password: hash, role: 'student', createdAt: new Date() };
      await users.insertOne(user);
      const token = jwt.sign({ id: user.id, email: user.email, role: 'student' }, JWT_SECRET, { expiresIn: '30d' });
      return json({ token, user: { id: user.id, email: user.email, role: 'student' } });
    }

    if (path === 'auth/login' && method === 'POST') {
      const { email, password } = await req.json();
      const users = database.collection('users');
      const user = await users.findOne({ email: (email || '').toLowerCase() });
      if (!user) return json({ error: 'Email atau password salah' }, 401);
      const ok = await bcrypt.compare(password, user.password);
      if (!ok) return json({ error: 'Email atau password salah' }, 401);
      const token = jwt.sign({ id: user.id, email: user.email, role: 'student' }, JWT_SECRET, { expiresIn: '30d' });
      return json({ token, user: { id: user.id, email: user.email, role: 'student' } });
    }

    if (path === 'auth/admin-login' && method === 'POST') {
      const { email, password } = await req.json();
      const admins = database.collection('admins');
      const admin = await admins.findOne({ email: (email || '').toLowerCase() });
      if (!admin) return json({ error: 'Email atau password admin salah' }, 401);
      const ok = await bcrypt.compare(password, admin.password);
      if (!ok) return json({ error: 'Email atau password admin salah' }, 401);
      const token = jwt.sign({ id: admin.id, email: admin.email, role: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
      return json({ token, user: { id: admin.id, email: admin.email, role: 'admin', mustChangePassword: !!admin.mustChangePassword } });
    }

    if (path === 'auth/admin-change-password' && method === 'POST') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'admin') return json({ error: 'Unauthorized' }, 401);
      const { newPassword } = await req.json();
      if (!newPassword || newPassword.length < 6) return json({ error: 'Password minimal 6 karakter' }, 400);
      const hash = await bcrypt.hash(newPassword, 10);
      await database.collection('admins').updateOne({ id: auth.id }, { $set: { password: hash, mustChangePassword: false } });
      return json({ ok: true });
    }

    if (path === 'me' && method === 'GET') {
      const auth = verifyToken(req);
      if (!auth) return json({ error: 'Unauthorized' }, 401);
      return json({ user: { id: auth.id, email: auth.email, role: auth.role } });
    }

    // -------- POSTS (PUBLIC FEED) --------
    if (path === 'posts' && method === 'GET') {
      const tab = url.searchParams.get('tab') || 'terbaru';
      const category = url.searchParams.get('category') || '';
      const search = url.searchParams.get('search') || '';
      const filter = { approved: true };
      if (category && category !== 'Semua') filter.category = category;
      if (search) {
        filter.$or = [
          { title: { $regex: search, $options: 'i' } },
          { content: { $regex: search, $options: 'i' } }
        ];
      }
      let sort = { createdAt: -1 };
      if (tab === 'trending') {
        const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        filter.createdAt = { $gte: since };
        sort = { supportCount: -1, createdAt: -1 };
      } else if (tab === 'terbanyak') {
        sort = { supportCount: -1, createdAt: -1 };
      }
      const posts = await database.collection('posts').find(filter).sort(sort).limit(100).toArray();
      const auth = verifyToken(req);
      const myId = auth?.id;
      const result = posts.map(p => ({
        ...cleanPost(p),
        hasSupported: myId ? (p.supporters || []).includes(myId) : false,
        supporters: undefined
      }));
      return json({ posts: result });
    }

    if (path === 'posts' && method === 'POST') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'student') return json({ error: 'Silakan login terlebih dahulu' }, 401);
      const { title, content, category } = await req.json();
      if (!title || !content || !category) return json({ error: 'Judul, isi, dan kategori wajib diisi' }, 400);
      const flags = autoModerate(title, content);
      const post = {
        id: uuidv4(),
        title: title.trim().slice(0, 200),
        content: content.trim().slice(0, 4000),
        category,
        status: 'Menunggu Review',
        supportCount: 0,
        supporters: [],
        authorHash: uuidv4(), // anonymous hash, no link to user shown publicly
        authorId: auth.id,    // server-only for support uniqueness/admin
        moderationFlags: flags,
        flagged: flags.length > 0,
        approved: flags.length === 0, // auto-approve clean posts, hide flagged until admin review
        createdAt: new Date()
      };
      await database.collection('posts').insertOne(post);
      return json({ ok: true, post: { ...cleanPost(post), authorId: undefined, supporters: undefined } });
    }

    const supportMatch = path.match(/^posts\/([^/]+)\/support$/);
    if (supportMatch && method === 'POST') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'student') return json({ error: 'Silakan login untuk mendukung' }, 401);
      const postId = supportMatch[1];
      const posts = database.collection('posts');
      const post = await posts.findOne({ id: postId });
      if (!post) return json({ error: 'Aspirasi tidak ditemukan' }, 404);
      const supporters = post.supporters || [];
      if (supporters.includes(auth.id)) {
        // toggle off
        await posts.updateOne({ id: postId }, { $pull: { supporters: auth.id }, $inc: { supportCount: -1 } });
        return json({ ok: true, hasSupported: false, supportCount: Math.max(0, (post.supportCount || 0) - 1) });
      }
      await posts.updateOne({ id: postId }, { $addToSet: { supporters: auth.id }, $inc: { supportCount: 1 } });
      return json({ ok: true, hasSupported: true, supportCount: (post.supportCount || 0) + 1 });
    }

    // -------- ADMIN --------
    if (path === 'admin/stats' && method === 'GET') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'admin') return json({ error: 'Unauthorized' }, 401);
      const posts = database.collection('posts');
      const [total, menunggu, diproses, selesai, flagged] = await Promise.all([
        posts.countDocuments({}),
        posts.countDocuments({ status: 'Menunggu Review' }),
        posts.countDocuments({ status: 'Diproses' }),
        posts.countDocuments({ status: 'Selesai' }),
        posts.countDocuments({ flagged: true, approved: false })
      ]);
      const byCategory = await posts.aggregate([{ $group: { _id: '$category', count: { $sum: 1 } } }]).toArray();
      return json({ total, menunggu, diproses, selesai, flagged, byCategory });
    }

    if (path === 'admin/posts' && method === 'GET') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'admin') return json({ error: 'Unauthorized' }, 401);
      const filterParam = url.searchParams.get('filter') || 'all';
      const filter = {};
      if (filterParam === 'pending_review') { filter.flagged = true; filter.approved = false; }
      else if (filterParam === 'menunggu') filter.status = 'Menunggu Review';
      else if (filterParam === 'diproses') filter.status = 'Diproses';
      else if (filterParam === 'selesai') filter.status = 'Selesai';
      const list = await database.collection('posts').find(filter).sort({ createdAt: -1 }).limit(200).toArray();
      return json({ posts: list.map(p => ({ ...cleanPost(p), authorId: undefined, supporters: undefined })) });
    }

    const adminPostMatch = path.match(/^admin\/posts\/([^/]+)$/);
    if (adminPostMatch && method === 'PATCH') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'admin') return json({ error: 'Unauthorized' }, 401);
      const id = adminPostMatch[1];
      const body = await req.json();
      const update = {};
      if (body.status) update.status = body.status;
      if (body.action === 'approve') { update.approved = true; update.flagged = false; }
      if (body.action === 'reject') { update.approved = false; }
      if (Object.keys(update).length === 0) return json({ error: 'Tidak ada perubahan' }, 400);
      await database.collection('posts').updateOne({ id }, { $set: update });
      return json({ ok: true });
    }

    if (adminPostMatch && method === 'DELETE') {
      const auth = verifyToken(req);
      if (!auth || auth.role !== 'admin') return json({ error: 'Unauthorized' }, 401);
      const id = adminPostMatch[1];
      await database.collection('posts').deleteOne({ id });
      return json({ ok: true });
    }

    if (path === '' || path === 'health') {
      return json({ status: 'ok', service: 'Ruang Siswa API' });
    }

    return json({ error: 'Not found', path }, 404);
  } catch (e) {
    console.error('API error', e);
    return json({ error: 'Server error', message: e.message }, 500);
  }
}

export const GET = handle;
export const POST = handle;
export const PATCH = handle;
export const PUT = handle;
export const DELETE = handle;
