import './globals.css';
import { Inter } from 'next/font/google';
import { Toaster } from '@/components/ui/sonner';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata = {
  title: 'Ruang Siswa - Aspirasi Siswa Anonim',
  description: 'Platform aspirasi siswa anonim. Ekspresikan ide, keluhan, atau saran untuk sekolahmu dengan aman dan transparan.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id" className="dark" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans bg-background text-foreground antialiased min-h-screen`}>
        {children}
        <Toaster position="top-center" richColors />
      </body>
    </html>
  );
}
